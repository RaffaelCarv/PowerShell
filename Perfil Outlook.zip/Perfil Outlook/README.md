# 📨 Criação de Perfil Outlook "IEC"

Este projeto contém um conjunto de scripts para criar e iniciar automaticamente um novo perfil no Microsoft Outlook chamado **IEC**. Essa abordagem é ideal para ambientes que estão migrando do **Exchange 2010 para o Microsoft 365**, onde é necessário criar um novo perfil para suportar a autenticação moderna (OAuth).

---

## 📦 Conteúdo do Arquivo `.zip`

| Arquivo                    | Descrição                                                                 |
|----------------------------|---------------------------------------------------------------------------|
| `CreateOutlookProfile.ps1` | Script PowerShell que cria e inicia o perfil Outlook `IEC`                |
| `criar_perfil_IEC.prf`     | Arquivo `.PRF` vazio utilizado para iniciar um novo perfil                |
| `executar_perfil.cmd`      | Script `.cmd` que executa o PowerShell com permissões apropriadas         |

---

## 🧾 Instruções de Uso

### 1. Extração

Extraia todos os arquivos do `.zip` para uma pasta local no computador, por exemplo:

```
C:\Scripts\PerfilOutlook\
```

---

### 2. Execução

> ⚠️ **É obrigatório executar como administrador.**

- Localize o arquivo `executar_perfil.cmd`
- Clique com o botão direito sobre ele
- Escolha a opção **"Executar como administrador"**

---

## ⚙️ O Que o Script Faz

- Verifica se o perfil Outlook com nome **IEC** já existe:
  - Se **já existir**, exibe uma mensagem e encerra.
  - Se **não existir**, executa o Outlook com o arquivo `.PRF` para criar o novo perfil.

- Em seguida, o Outlook é iniciado com o novo perfil, e o **assistente de configuração automático (Autodiscover)** será iniciado para configurar sua conta do Microsoft 365 com suporte a OAuth.

---

## ✅ Observações Importantes

- O processo **não remove nem altera** perfis anteriores.
- O arquivo `.PRF` é propositalmente **vazio** e **não configura contas de e-mail**.
- A conta será configurada automaticamente pelo Outlook após o novo perfil ser iniciado.
- O script não precisa de alterações manuais.
- **Execute sempre como administrador**, principalmente em ambientes com restrições de segurança.

---

## 🛟 Suporte

Caso ocorra algum erro ou comportamento inesperado, entre em contato com o suporte técnico da sua organização antes de tentar novamente.
