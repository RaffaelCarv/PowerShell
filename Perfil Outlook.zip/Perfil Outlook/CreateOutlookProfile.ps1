<#
    Criado por: Rafael Carvalho
    GitHub: https://github.com/RaffaelCarv/PowerShell
    Data de criacao: 20 de junho de 2025
    Descricao:
    Este script verifica se o perfil "IEC" existe. Se nao existir, importa um arquivo .PRF
    e inicia o Outlook com o novo perfil, permitindo que o assistente moderno (OAuth) configure a conta.
#>

Add-Type -AssemblyName System.Windows.Forms

$profileName = "IEC"
$prfPath = Join-Path -Path $PSScriptRoot -ChildPath "criar_perfil_IEC.prf"

# Funcao para mostrar alerta
function Show-Popup {
    param([string]$message, [string]$title = "Aviso")
    [System.Windows.Forms.MessageBox]::Show($message, $title, 'OK', 'Information') | Out-Null
}

# Detecta versao do Outlook
function Get-OutlookVersion {
    $versions = @("16.0", "15.0", "14.0", "12.0")
    foreach ($ver in $versions) {
        $key = "HKCU:\Software\Microsoft\Office\$ver\Outlook"
        if (Test-Path $key) {
            return $ver
        }
    }
    return $null
}

# Verifica se o perfil existe
function Profile-Exists {
    param([string]$version, [string]$profileName)
    $key = "HKCU:\Software\Microsoft\Office\$version\Outlook\Profiles\$profileName"
    return (Test-Path $key)
}

# EXECUCAO
$version = Get-OutlookVersion

if (-not $version) {
    Show-Popup "Outlook nao encontrado nesta maquina." "Erro"
    exit 1
}

if (Profile-Exists -version $version -profileName $profileName) {
    Show-Popup "O perfil '$profileName' ja existe. Nenhuma acao necessaria." "Informacao"
    exit 0
}

if (-not (Test-Path $prfPath)) {
    Show-Popup "Arquivo .PRF nao encontrado em: $prfPath" "Erro"
    exit 1
}

# Importa o .PRF para criar o perfil novo
Start-Process "outlook.exe" -ArgumentList "/importprf `"$prfPath`""

# Abre Outlook com o novo perfil
Start-Process "outlook.exe" -ArgumentList "/profile $profileName"

Show-Popup "O Outlook foi iniciado com o novo perfil '$profileName'. Siga o assistente para configurar sua conta M365."
